# ParkingLotDetection

This project used network of cameras and computer vision in order to determine availability of parking spaces across system of parking lots.

Project poster: 
<img src="https://i.imgur.com/kZ4tDhX.png">

The poster for this project can be seen from this [link](https://docs.google.com/presentation/d/1yYbIFn2G3bV2_fa-43-3-19Iob1JFqr1gMfnYJu8dc0/edit?usp=sharing).

The progress for our can be seen from this [link](https://winlab2017.wixsite.com/parking).

When you wanted to run this code, you must first initialize your system by running SmartParking.py. And then you run app.py which can show final result on the webpage.
